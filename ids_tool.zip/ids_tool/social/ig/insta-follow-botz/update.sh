#!/bin/bash

echo -e " updating " |lolcat
echo ""
echo ""
cd ..
echo " please wait "| pv -qL 50| lolcat
echo ""
echo ""


rm -rf  insta-follow-botz

git clone https://github.com/DRACULA-HACK/insta-follow-botz
clear
cd insta-follow-botz

chmod +x insta4.sh

./insta4.sh
