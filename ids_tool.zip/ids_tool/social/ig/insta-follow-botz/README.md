
# Insta-follow-botz



![49071cfb-e147-485d-bad6-97570a657a21](https://user-images.githubusercontent.com/96709855/185073180-e6587b1f-80bf-4fb4-aec0-e4485e3cf519.jpg)



# Features

Unfollow Tracker
#
Increase your Followers
#
Download the Stores
#
Download the Saved Content
#
Download the Following List
#
Download the Followers List
#
Download the Profile Information
#
Activate Unfollower
#
instagram information gathering
#
install instagram mod apk             
#
#
It is a bot of 25 accounts And the trick follow And Unfollow make more then 20 in 1hr

And it have more features also in instagram info gathering we add the Tool insta hack 
And it have insta report , information gathering ,And brute force
#
And in option 10 you can install the instagram mod which created by Sam bro mods And ad mods
#
#
https://www.instamod.net/2021/08/insta-thunder-latest-version-apk.html?m=1
#
` `
#
 Tool is also created fore TERMUX users

#
# installation

#

` apt install git `


` apt install figlet -y `

` apt install toilet -y `

` apt install cowsay -y `

` apt install nano -y `

` apt install ruby -y `

` gem install lolcat `

` apt install git curl openssh openssl openssl-tool -y `
#

` git clone https://github.com/DRACULA-HACK/insta-follow-botz.git `

` cd insta-follow-botz `

` chmod +x insta4.sh `

` ./insta4.sh `
#
#
Or
#
` bash insta4.sh `
#
# gave the credit 
# Insta
https://instagram.com/_master_hack_?igshid=YmMyMTA2M2Y=
#
# YouTube
https://youtube.com/channel/UC5HIWT2iUznhNFX0BzukXUQ
#
# whatsapp 
https://wa.me/+916235369260
#
