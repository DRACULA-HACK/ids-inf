# ntha mowna edu uru chugam

termux-open-url https://iplogger.org

printf ("hi")


