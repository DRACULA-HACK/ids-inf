# C-hacks
Hi am nidhin
#
Its a social Media gathering Tool And its have whatsapp hacks ,
Fb hacks , instagram hacks , And information gathering
. The main script is that I has added ip location tracking file
created by MASTER-HACK And its has ip phishing extra
On whatsapp hacks I has added moded whatsapp whatsapp virus extra
That's it . Happy learning And don't forget to
Bash my Chack.sh file . enjoy the Tool bro ..
#
Its only for education purposes
#
# Installation
#
` apt update -y && apt upgrade -y `

` apt install git -y `

` git clone https://github.com/DRACULA-HACK/C-hacks `

` cd C-hacks `

` chmod +x Chack.sh `

` ./Chack.sh `
#
created by
MASTER-HACK
#
™𝚰𝚴𝛁𝚫𝐃𝚺𝐑𝐒 𝚯𝐅𝐂 🪁
#
https://wa.me//+916235369260 
