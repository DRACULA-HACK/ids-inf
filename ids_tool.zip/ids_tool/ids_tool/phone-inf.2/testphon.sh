clear
echo ""

echo -e " 
\033[1;36m 
      enter the target number to scan :

     "
echo -e " \033[1;34m            Type the country code with +

" | pv -qL 40
read -p " => " code

echo -e "  \033[1;36m number with out country code " | pv -qL 30

read -p " numb => " number



python3 phone-inf.py -n $code$number

