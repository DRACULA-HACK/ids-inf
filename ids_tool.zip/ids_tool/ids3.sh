{
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
blue='\033[1;34m'
cyan='\033[1;36m'
pink='\033[1;35m'
Purple='\033[1;35m'
Black='\033[0;30m'
clear
$ cat menu1
clear
figlet hello | lolcat

figlet wellcome | lolcat

echo -e "       To 
      "
figlet ids-inf | pv -qL 50 |lolcat

sleep 3

echo -e "        

             This tool is created by the invedars ofc 

                             . master-hack

"| pv -qL 50 |lolcat


echo ""


echo -e " 
        ┈┈┈┈╱▔▔▔▔╲┈┈┈┈
        ┈┈┈▕▕╲┊┊╱▏▏┈┈┈
        ┈┈┈▕▕▂╱╲▂▏▏┈┈┈
        ┈┈┈┈╲┊┊┊┊╱┈┈┈┈
        ┈┈┈┈▕╲▂▂╱▏┈┈┈┈
        ╱▔▔▔▔┊┊┊┊▔▔▔▔╲
    
" |pv -qL 100 |lolcat


echo -e "

 $Purple

        OPTION'S
        
        (1) phone number information 
        
        (2) IP tracker
        
        (3) SOCIAL MEDIA (information)
        
        (4) number (unbaner)
      
       
        (0) exit 
        
        $red
        "|pv -qL 40
        
       read -p "  select your option  :- " inf
        
if [ $inf = 1 ];then

figlet WELCOME | pv -qL 50 |lolcat

cd phone-inf.2
bash testphon.sh


elif [ $inf = 2 ];then 


bash ip3.py

elif [ $inf = 3 ];then 
echo "hi "

social()

{

echo -e "  

		(1) insta inf
		
		(2) fb inf

		(0) exit

		"
		
		read -p "  select your option  :- " socialinf
if [ $socialinf = 1 ];then

cd social/ig/insta-follow-botz
bash insta4.sh
elif [ $socialinf = 2 ];then
cd social/fb/C-hacks
bash Chack.sh

else

wrong option

menu
fi


}

elif [ $socialinf = 0 ];then 
	exit

elif [ $inf = 4 ];then

echo "mail"
cd ban/mail
python2 mail4.sh
elif [ $inf = 0 ];then

echo " Oky bye "


else

echo -e "


        ╭━┳━╭━╭━╮╮
        ┃┈┈┈┣▅╋▅┫┃
        ┃┈┃┈╰━╰━━━━━━╮
        ╰┳╯┈┈┈┈┈┈┈┈┈◢▉◣
        ╲┃┈┈┈┈┈┈┈┈┈┈▉▉▉
        ╲┃┈┈┈┈┈┈┈┈┈┈◥▉◤
        ╲┃┈┈┈┈╭━┳━━━━╯
        ╲┣━━━━━━┫
        "|pv -qL 50 |lolcat
echo -e "wrong option "

bash ids3.sh

fi




}
